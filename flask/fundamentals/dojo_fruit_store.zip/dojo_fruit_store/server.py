from flask import Flask, render_template, request, redirect
app = Flask(__name__)  
app.secret_key = "secret key"

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    strawberry_count = request.form["strawberry"]
    raspberry_count  = request.form["raspberry"]
    apple_count = request.form["apple"]

    fruit_count = int(strawberry_count) + int(raspberry_count) + int(apple_count)

    first_name = request.form["first_name"]
    last_name = request.form["last_name"]

    student_id = request.form["student_id"]

    print(request.form)
    
    print(f"\nCharging {first_name} for {fruit_count}\n")

    return render_template("checkout.html",
                            strawberry_count = strawberry_count,
                            raspberry_count = raspberry_count,
                            apple_count = apple_count,
                            first_name = first_name,
                            last_name = last_name,
                            student_id = student_id)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug = True, port = 5001)    